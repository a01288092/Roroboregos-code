#include <Arduino.h>
#include <cmath>
#include <cstring>
#include <algorithm>
#include "aruco_dict.h"

// Pin indicador LED fisico
#define LED_INDICATOR_PIN 2

#define MAX_WIDTH   160
#define MAX_HEIGHT  120
#define MAX_PIXELS  (MAX_WIDTH * MAX_HEIGHT)
#define MAX_RGB_BYTES (MAX_PIXELS * 3)

static uint8_t rawRgbBuffer[MAX_RGB_BYTES];
static uint8_t grayBuffer[MAX_PIXELS];
static uint8_t blurBuffer[MAX_PIXELS];
static uint8_t binBuffer[MAX_PIXELS];

// Temporizador del indicador fisico ArUco (Regla de 3 segundos continuos)
static unsigned long arucoActiveUntil = 0;
static int lastDetectedArucoId = -1;
static bool isArucoActive = false;
static int lastMinX = 0, lastMaxX = 0, lastMinY = 0, lastMaxY = 0;

// =========================================================================
// DETECTOR ARUCO 4X4_50 DE ALTA VELOCIDAD (NORMAL Y ESPEJO)
// =========================================================================
int detectArucoFromGray(const uint8_t* gray, int w, int h) {
  // 1. Calcular umbral optimo Otsu
  int hist[256];
  memset(hist, 0, sizeof(hist));
  int totalPixels = w * h;
  for (int i = 0; i < totalPixels; i++) {
    hist[gray[i]]++;
  }

  int sumTotal = 0;
  for (int t = 0; t < 256; t++) {
    sumTotal += t * hist[t];
  }

  int sumB = 0;
  int wB = 0;
  float maxVariance = 0.0f;
  uint8_t otsuThresh = 128;

  for (int t = 0; t < 256; t++) {
    wB += hist[t];
    if (wB == 0) continue;
    int wF = totalPixels - wB;
    if (wF == 0) break;

    sumB += t * hist[t];
    float mB = (float)sumB / wB;
    float mF = (float)(sumTotal - sumB) / wF;
    float varBetween = (float)wB * (float)wF * (mB - mF) * (mB - mF);
    if (varBetween > maxVariance) {
      maxVariance = varBetween;
      otsuThresh = t;
    }
  }

  // 2. Encontrar caja delimitadora del area oscura (el cuadrado negro del ArUco)
  int minX = w, maxX = 0, minY = h, maxY = 0;
  int darkCount = 0;
  for (int y = 0; y < h; y++) {
    int row = y * w;
    for (int x = 0; x < w; x++) {
      if (gray[row + x] < otsuThresh) {
        darkCount++;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }

  // Si no hay suficiente area negra, o la caja es diminuta
  int bw = maxX - minX + 1;
  int bh = maxY - minY + 1;
  if (darkCount < (totalPixels * 0.10) || bw < 14 || bh < 14) {
    return -1;
  }

  // 3. Muestrear rejilla 6x6
  float cw = (float)bw / 6.0f;
  float ch = (float)bh / 6.0f;
  uint8_t samples[6][6];
  uint8_t minL = 255, maxL = 0;

  for (int r = 0; r < 6; r++) {
    int py = minX + (int)((r + 0.5f) * ch);
    py = std::max(minY, std::min(maxY, (int)(minY + (r + 0.5f) * ch)));
    for (int c = 0; c < 6; c++) {
      int px = std::max(minX, std::min(maxX, (int)(minX + (c + 0.5f) * cw)));
      uint8_t val = gray[py * w + px];
      samples[r][c] = val;
      if (val < minL) minL = val;
      if (val > maxL) maxL = val;
    }
  }

  if ((maxL - minL) < 25) return -1;
  uint8_t midThresh = (minL + maxL) / 2;

  // 4. Verificar marco negro exterior (debe ser mayoritariamente negro)
  int blackBorder = 0;
  for (int i = 0; i < 6; i++) {
    if (samples[0][i] < midThresh) blackBorder++;
    if (samples[5][i] < midThresh) blackBorder++;
    if (i > 0 && i < 5) {
      if (samples[i][0] < midThresh) blackBorder++;
      if (samples[i][5] < midThresh) blackBorder++;
    }
  }

  if (blackBorder >= 14) {
    // 5. Decodificar bits interiores 4x4 (tanto normal como espejo horizontal)
    uint16_t codeNormal = 0;
    uint16_t codeFlipped = 0;

    for (int r = 1; r <= 4; r++) {
      for (int c = 1; c <= 4; c++) {
        int bitN = (samples[r][c] >= midThresh) ? 1 : 0;
        codeNormal = (codeNormal << 1) | bitN;

        // Version invertida horizontalmente (para webcams en modo espejo)
        int bitF = (samples[r][5 - c] >= midThresh) ? 1 : 0;
        codeFlipped = (codeFlipped << 1) | bitF;
      }
    }

    // Buscar coincidencia en diccionario ArUco 4x4_50
    for (int id = 0; id < 50; id++) {
      for (int rot = 0; rot < 4; rot++) {
        uint16_t dictVal = ARUCO_DICT_4X4_50[id][rot];
        if (codeNormal == dictVal || codeFlipped == dictVal) {
          lastMinX = minX;
          lastMaxX = maxX;
          lastMinY = minY;
          lastMaxY = maxY;
          return id;
        }
      }
    }
  }

  return -1;
}

// =========================================================================
// CLASIFICADOR DE COLORES DEL RETO (CIAN, AMARILLO, NARANJA, MAGENTA)
// =========================================================================
const char* classifyColor(const uint8_t* rgb, int w, int h) {
  long sumR = 0, sumG = 0, sumB = 0;
  int count = 0;

  // Muestrear zona central del 50%
  int x0 = w / 4, x1 = (w * 3) / 4;
  int y0 = h / 4, y1 = (h * 3) / 4;

  for (int y = y0; y < y1; y++) {
    int row = y * w * 3;
    for (int x = x0; x < x1; x++) {
      int idx = row + x * 3;
      sumR += rgb[idx];
      sumG += rgb[idx + 1];
      sumB += rgb[idx + 2];
      count++;
    }
  }

  if (count == 0) return "ninguno";

  float r = (float)sumR / (count * 255.0f);
  float g = (float)sumG / (count * 255.0f);
  float b = (float)sumB / (count * 255.0f);

  float maxC = std::max({r, g, b});
  float minC = std::min({r, g, b});
  float delta = maxC - minC;

  if (maxC < 0.20f || delta < 0.15f) {
    return "ninguno";
  }

  float hue = 0.0f;
  if (delta > 0.0001f) {
    if (maxC == r) {
      hue = 60.0f * std::fmod(((g - b) / delta), 6.0f);
    } else if (maxC == g) {
      hue = 60.0f * (((b - r) / delta) + 2.0f);
    } else {
      hue = 60.0f * (((r - g) / delta) + 4.0f);
    }
    if (hue < 0.0f) hue += 360.0f;
  }

  if (hue >= 160.0f && hue < 215.0f) return "cian";
  if (hue >= 40.0f && hue < 75.0f)   return "amarillo";
  if (hue >= 10.0f && hue < 40.0f)   return "naranja";
  if (hue >= 285.0f && hue < 350.0f) return "magenta";

  return "ninguno";
}

// =========================================================================
// DETECTOR DE LINEA BLANCA
// =========================================================================
bool detectWhiteLine(const uint8_t* gray, int w, int h, float& offsetX) {
  int brightCount = 0;
  long sumX = 0;

  for (int y = 0; y < h; y++) {
    int row = y * w;
    for (int x = 0; x < w; x++) {
      if (gray[row + x] > 200) {
        brightCount++;
        sumX += x;
      }
    }
  }

  if (brightCount > (w * h * 0.08) && brightCount < (w * h * 0.45)) {
    float avgX = (float)sumX / brightCount;
    offsetX = (avgX - (w / 2.0f)) / (w / 2.0f);
    return true;
  }

  offsetX = 0.0f;
  return false;
}

// =========================================================================
// SETUP Y BUCLE PRINCIPAL
// =========================================================================
void setup() {
  Serial.setRxBufferSize(65536);
  Serial.begin(2000000);
  pinMode(LED_INDICATOR_PIN, OUTPUT);
  digitalWrite(LED_INDICATOR_PIN, LOW);
  delay(100);

  Serial.println("\n[ESP32-S3] Sistema de Vision por Cable Listo (2000000 baudios).");
}

void processIncomingCommand(String cmd) {
  cmd.trim();

  if (cmd == "PING") {
    Serial.println("PONG");
    return;
  }

  if (cmd == "CLEAR") {
    digitalWrite(LED_INDICATOR_PIN, LOW);
    isArucoActive = false;
    Serial.println("OK");
    return;
  }

  // Comando: PROCESS RGB <w> <h> <bytes>
  if (cmd.startsWith("PROCESS RGB")) {
    int w = 48, h = 48, totalBytes = 48 * 48 * 3;
    sscanf(cmd.c_str(), "PROCESS RGB %d %d %d", &w, &h, &totalBytes);

    if (totalBytes > MAX_RGB_BYTES || w <= 0 || h <= 0) {
      Serial.println("{\"error\": \"Dimensiones fuera de rango\"}");
      return;
    }

    // Indicar al navegador / Python que estamos listos para recibir los bytes
    Serial.println("READY");
    Serial.flush();

    // Leer bytes raw
    int bytesRead = 0;
    unsigned long startWait = millis();
    while (bytesRead < totalBytes && millis() - startWait < 1500) {
      if (Serial.available()) {
        int avail = Serial.available();
        int toRead = std::min(avail, totalBytes - bytesRead);
        int r = Serial.readBytes((char*)(rawRgbBuffer + bytesRead), toRead);
        bytesRead += r;
        startWait = millis();
      }
    }

    if (bytesRead < totalBytes) {
      Serial.println("{\"error\": \"Timeout recibiendo fotograma\"}");
      return;
    }

    // 1. Convertir a escala de grises
    unsigned long t0 = millis();
    int pixels = w * h;
    for (int i = 0, j = 0; i < pixels; i++, j += 3) {
      grayBuffer[i] = (uint8_t)((rawRgbBuffer[j] * 77 + rawRgbBuffer[j + 1] * 150 + rawRgbBuffer[j + 2] * 29) >> 8);
    }

    // 2. Detectar ArUco
    int arucoId = detectArucoFromGray(grayBuffer, w, h);

    // 3. Detectar Color
    const char* col = classifyColor(rawRgbBuffer, w, h);

    // 4. Detectar Linea
    float offsetX = 0.0f;
    bool lineFound = detectWhiteLine(grayBuffer, w, h, offsetX);

    unsigned long elapsedMs = millis() - t0;

    // Manejar LED fisico
    if (arucoId >= 0) {
      lastDetectedArucoId = arucoId;
      isArucoActive = true;
      arucoActiveUntil = millis() + 3500; // 3.5 segundos continuos
      digitalWrite(LED_INDICATOR_PIN, HIGH);
    }

    // Respuesta JSON esperada por panel_cable.html
    Serial.printf("{\"aruco_id\": %d, \"color\": \"%s\", \"line_detected\": %s, \"offset_x\": %.2f, \"time_ms\": %lu}\n",
                  arucoId,
                  col,
                  lineFound ? "true" : "false",
                  offsetX,
                  elapsedMs);
    Serial.flush();
    return;
  }

  Serial.println("{\"error\": \"Comando desconocido\"}");
}

// Soporte para protocolo binario rapido (camara_esp32.html)
const uint8_t SOF_IN[4]  = { 0xFF, 0xAA, 0x55, 0xEE };
const uint8_t SOF_OUT[4] = { 0xEE, 0x55, 0xAA, 0xFF };
enum ParseBinState { BIN_IDLE, BIN_SOF1, BIN_SOF2, BIN_SOF3, BIN_HEADER, BIN_LINE_HDR, BIN_LINE_IDX, BIN_LINE_PIX };
static ParseBinState binState = BIN_IDLE;
static uint8_t binHdr[4];
static int binHdrIdx = 0;
static int curW = 80, curH = 60, curL = 0, lPixIdx = 0, lRecv = 0;
static bool is4BitBin = false;

void handleBinaryByte(uint8_t b) {
  switch (binState) {
    case BIN_IDLE:
      if (b == SOF_IN[0]) binState = BIN_SOF1;
      break;
    case BIN_SOF1:
      if (b == SOF_IN[1]) binState = BIN_SOF2;
      else binState = (b == SOF_IN[0]) ? BIN_SOF1 : BIN_IDLE;
      break;
    case BIN_SOF2:
      if (b == SOF_IN[2]) binState = BIN_SOF3;
      else binState = (b == SOF_IN[0]) ? BIN_SOF1 : BIN_IDLE;
      break;
    case BIN_SOF3:
      if (b == SOF_IN[3]) {
        binState = BIN_HEADER;
        binHdrIdx = 0;
      } else {
        binState = (b == SOF_IN[0]) ? BIN_SOF1 : BIN_IDLE;
      }
      break;
    case BIN_HEADER:
      binHdr[binHdrIdx++] = b;
      if (binHdrIdx == 4) {
        is4BitBin = (binHdr[0] & 0x80) != 0;
        curW = ((binHdr[0] & 0x7F) << 8) | binHdr[1];
        curH = (binHdr[2] << 8) | binHdr[3];
        if (curW > MAX_WIDTH) curW = MAX_WIDTH;
        if (curH > MAX_HEIGHT) curH = MAX_HEIGHT;
        lRecv = 0;
        binState = BIN_LINE_HDR;
      }
      break;
    case BIN_LINE_HDR:
      if (b == 0xA5) binState = BIN_LINE_IDX;
      break;
    case BIN_LINE_IDX:
      curL = b;
      lPixIdx = 0;
      binState = (curL < curH) ? BIN_LINE_PIX : BIN_LINE_HDR;
      break;
    case BIN_LINE_PIX:
      if (is4BitBin) {
        uint8_t p0 = (b >> 4) * 17;
        uint8_t p1 = (b & 0x0F) * 17;
        int baseIdx = curL * curW;
        if (lPixIdx < curW) grayBuffer[baseIdx + lPixIdx++] = p0;
        if (lPixIdx < curW) grayBuffer[baseIdx + lPixIdx++] = p1;
      } else {
        grayBuffer[curL * curW + lPixIdx++] = b;
      }
      if (lPixIdx >= curW) {
        lRecv++;
        if (lRecv >= curH) {
          unsigned long t0 = millis();
          int detId = detectArucoFromGray(grayBuffer, curW, curH);
          float lineOffset = 0.0f;
          bool lineFound = detectWhiteLine(grayBuffer, curW, curH, lineOffset);
          uint8_t cpu = (uint8_t)(millis() - t0);

          if (detId >= 0) {
            lastDetectedArucoId = detId;
            isArucoActive = true;
            arucoActiveUntil = millis() + 3500;
            digitalWrite(LED_INDICATOR_PIN, HIGH);
          }

          uint8_t respPacket[20];
          memcpy(respPacket, SOF_OUT, 4);
          respPacket[4] = (detId >= 0) ? 0x01 : 0x00;
          respPacket[5] = (uint8_t)(detId >= 0 ? detId : 255);
          respPacket[6] = cpu;
          respPacket[7] = lineFound ? 0x01 : 0x00;
          respPacket[8] = (uint8_t)((int8_t)(lineOffset * 100));
          respPacket[9] = 0x00;

          if (detId >= 0) {
            respPacket[10] = (uint8_t)std::max(0, std::min(255, lastMinX));
            respPacket[11] = (uint8_t)std::max(0, std::min(255, lastMinY));
            respPacket[12] = (uint8_t)std::max(0, std::min(255, lastMaxX));
            respPacket[13] = (uint8_t)std::max(0, std::min(255, lastMinY));
            respPacket[14] = (uint8_t)std::max(0, std::min(255, lastMaxX));
            respPacket[15] = (uint8_t)std::max(0, std::min(255, lastMaxY));
            respPacket[16] = (uint8_t)std::max(0, std::min(255, lastMinX));
            respPacket[17] = (uint8_t)std::max(0, std::min(255, lastMaxY));
          } else {
            memset(respPacket + 10, 0, 8);
          }
          respPacket[18] = 0x00;
          respPacket[19] = 0x00;

          Serial.write(respPacket, 20);
          Serial.flush();
          binState = BIN_IDLE;
        } else {
          binState = BIN_LINE_HDR;
        }
      }
      break;
  }
}

void loop() {
  // Manejo del indicador LED fisico
  if (isArucoActive) {
    if (millis() < arucoActiveUntil) {
      digitalWrite(LED_INDICATOR_PIN, HIGH);
    } else {
      digitalWrite(LED_INDICATOR_PIN, LOW);
      isArucoActive = false;
    }
  }

  if (Serial.available()) {
    int peekByte = Serial.peek();
    if (peekByte == 0xFF) {
      handleBinaryByte(Serial.read());
    } else {
      String line = Serial.readStringUntil('\n');
      processIncomingCommand(line);
    }
  }
}
