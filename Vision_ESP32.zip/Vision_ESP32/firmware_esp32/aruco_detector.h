#ifndef ARUCO_DETECTOR_H
#define ARUCO_DETECTOR_H

#include <stdint.h>
#include <math.h>
#include <string.h>

#include "aruco_dict.h"
#include "aruco_lut.h"

#ifndef pgm_read_word
#define pgm_read_word(addr) (*(addr))
#endif
#ifndef pgm_read_byte
#define pgm_read_byte(addr) (*(addr))
#endif

struct ArUcoDetection {
    int id;
    int cx, cy;
    int size;
    int confidence; // 0 o 1 hamming distance
};

// Algoritmo embebido de deteccion ArUco 4x4 ultra-rapido para ESP32-S3
class ArUcoDetectorS3 {
public:
    static ArUcoDetection detect(const uint8_t* img, int w, int h) {
        ArUcoDetection result = { -1, 0, 0, 0, 99 };
        if (!img || w < 20 || h < 20) return result;

        // 1. Umbral dinamico rapido muestreando cada 4 pixeles
        uint32_t sum = 0;
        int samples = 0;
        for (int y = 0; y < h; y += 4) {
            for (int x = 0; x < w; x += 4) {
                sum += img[y * w + x];
                samples++;
            }
        }
        uint8_t avg = (uint8_t)(sum / samples);
        uint8_t thresh = (uint8_t)((avg * 78) / 100); // 78% del promedio para aislar negros

        // Buffer de visitados en pila o memoria (1 bit por pixel o 1 byte cada 2 pixeles)
        // Para 160x120 o 320x240, usaremos un arreglo estatico de marcas
        static uint8_t visited[640 * 480 / 8];
        int total_pixels = w * h;
        if (total_pixels > 640 * 480) total_pixels = 640 * 480;
        memset(visited, 0, (total_pixels + 7) / 8);

        auto is_visited = [&](int idx) -> bool {
            return (visited[idx >> 3] & (1 << (idx & 7))) != 0;
        };
        auto set_visited = [&](int idx) {
            visited[idx >> 3] |= (1 << (idx & 7));
        };

        // Cola circular estatica para BFS
        const int MAX_Q = 4096;
        static uint16_t qx[MAX_Q];
        static uint16_t qy[MAX_Q];

        // 2. Escaneo de componentes oscuros
        for (int y = 4; y < h - 4; y += 2) {
            for (int x = 4; x < w - 4; x += 2) {
                int idx = y * w + x;
                if (img[idx] < thresh && !is_visited(idx)) {
                    // Iniciar BFS
                    int q_head = 0, q_tail = 0;
                    qx[q_tail] = x;
                    qy[q_tail] = y;
                    q_tail = (q_tail + 1) % MAX_Q;
                    set_visited(idx);

                    int area = 0;
                    int min_x = x, max_x = x;
                    int min_y = y, max_y = y;

                    // Esquinas extremas
                    int c0_x = x, c0_y = y, min_sum = x + y;       // Top-Left (min x+y)
                    int c1_x = x, c1_y = y, max_diff = x - y;      // Top-Right (max x-y)
                    int c2_x = x, c2_y = y, max_sum = x + y;       // Bottom-Right (max x+y)
                    int c3_x = x, c3_y = y, min_diff = x - y;      // Bottom-Left (min x-y)

                    while (q_head != q_tail) {
                        int cx = qx[q_head];
                        int cy = qy[q_head];
                        q_head = (q_head + 1) % MAX_Q;
                        area++;

                        if (cx < min_x) min_x = cx;
                        if (cx > max_x) max_x = cx;
                        if (cy < min_y) min_y = cy;
                        if (cy > max_y) max_y = cy;

                        int s = cx + cy;
                        int d = cx - cy;
                        if (s < min_sum)  { min_sum = s;  c0_x = cx; c0_y = cy; }
                        if (d > max_diff) { max_diff = d; c1_x = cx; c1_y = cy; }
                        if (s > max_sum)  { max_sum = s;  c2_x = cx; c2_y = cy; }
                        if (d < min_diff) { min_diff = d; c3_x = cx; c3_y = cy; }

                        // Vecinos 4-conectados
                        const int n_dx[4] = {1, -1, 0, 0};
                        const int n_dy[4] = {0, 0, 1, -1};
                        for (int i = 0; i < 4; ++i) {
                            int nx = cx + n_dx[i];
                            int ny = cy + n_dy[i];
                            if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
                                int n_idx = ny * w + nx;
                                if (img[n_idx] < thresh && !is_visited(n_idx)) {
                                    set_visited(n_idx);
                                    int next_tail = (q_tail + 1) % MAX_Q;
                                    if (next_tail != q_head) {
                                        qx[q_tail] = nx;
                                        qy[q_tail] = ny;
                                        q_tail = next_tail;
                                    }
                                }
                            }
                        }
                    }

                    int bw = max_x - min_x + 1;
                    int bh = max_y - min_y + 1;

                    // Filtrar por tamaño minimo y aspect ratio razonable
                    int min_dim = (w < h ? w : h);
                    int min_sz = min_dim / 10;
                    if (bw >= min_sz && bh >= min_sz && area >= (min_sz * min_sz / 2)) {
                        float aspect = (float)bw / (float)bh;
                        if (aspect >= 0.65f && aspect <= 1.55f) {
                            // 3. Muestrear la grilla 6x6 usando las esquinas c0, c1, c2, c3
                            uint8_t sample_vals[6][6];
                            uint8_t m_min = 255, m_max = 0;
                            for (int r = 0; r < 6; ++r) {
                                float v = (r + 0.5f) / 6.0f;
                                for (int c = 0; c < 6; ++c) {
                                    float u = (c + 0.5f) / 6.0f;
                                    float px = (1.0f - u) * (1.0f - v) * c0_x +
                                               u * (1.0f - v) * c1_x +
                                               u * v * c2_x +
                                               (1.0f - u) * v * c3_x;
                                    float py = (1.0f - u) * (1.0f - v) * c0_y +
                                               u * (1.0f - v) * c1_y +
                                               u * v * c2_y +
                                               (1.0f - u) * v * c3_y;

                                    int ix = (int)(px + 0.5f);
                                    int iy = (int)(py + 0.5f);
                                    if (ix < 0) ix = 0; if (ix >= w) ix = w - 1;
                                    if (iy < 0) iy = 0; if (iy >= h) iy = h - 1;

                                    uint8_t val = img[iy * w + ix];
                                    sample_vals[r][c] = val;
                                    if (val < m_min) m_min = val;
                                    if (val > m_max) m_max = val;
                                }
                            }

                            // Umbral adaptativo local entre el negro y blanco del marcador
                            uint8_t local_thresh = thresh;
                            if ((m_max - m_min) >= 18) {
                                local_thresh = (uint8_t)((m_min + m_max) / 2);
                            }

                            uint8_t grid[6][6];
                            for (int r = 0; r < 6; ++r) {
                                for (int c = 0; c < 6; ++c) {
                                    grid[r][c] = (sample_vals[r][c] > local_thresh) ? 1 : 0;
                                }
                            }

                            // 4. Validar borde exterior (debe ser predominantemente negro)
                            int border_white = 0;
                            for (int c = 0; c < 6; ++c) {
                                if (grid[0][c] == 1) border_white++;
                                if (grid[5][c] == 1) border_white++;
                            }
                            for (int r = 1; r < 5; ++r) {
                                if (grid[r][0] == 1) border_white++;
                                if (grid[r][5] == 1) border_white++;
                            }

                            if (border_white <= 3) {
                                // 5. Extraer 16 bits interiores
                                uint16_t codeword = 0;
                                for (int r = 1; r <= 4; ++r) {
                                    for (int c = 1; c <= 4; ++c) {
                                        codeword = (codeword << 1) | grid[r][c];
                                    }
                                }

                                // 6. Busqueda directa O(1) en tabla de aceleracion Flash (PROGMEM)
                                int8_t matched_id = (int8_t)pgm_read_byte(&ARUCO_LUT_ID[codeword]);
                                if (matched_id >= 0) {
                                    result.id = matched_id;
                                    result.cx = (min_x + max_x) / 2;
                                    result.cy = (min_y + max_y) / 2;
                                    result.size = (bw + bh) / 2;
                                    result.confidence = pgm_read_byte(&ARUCO_LUT_DIST[codeword]);
                                    return result;
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }
};

#endif // ARUCO_DETECTOR_H
