#ifndef ARUCO_DICT_H
#define ARUCO_DICT_H

#include <stdint.h>

extern const uint16_t ARUCO_DICT_4X4_50[50][4];

#endif // ARUCO_DICT_H
