# Modulo de Vision Artificial - RoBorregos Candidates 2026

Esta carpeta reune exclusivamente los componentes de software desarrollados para la deteccion visual del robot (Marcadores ArUco 4x4_50, Clasificacion de Colores y Deteccion de Lineas Blancas).

---

## 1. Firmware C++ para ESP32-S3 (firmware_esp32/)

Contiene los algoritmos matematicos que corren dentro del microcontrolador sin librerias pesadas de vision:

* procesador_vision.cpp:
  - Binarizacion de imagen mediante el metodo de umbral Otsu.
  - Funcion detectArucoFromGray(): Aislamiento del cuadrado negro, remuestreo de cuadricula 6x6, decodificacion de los 16 bits interiores en orientacion normal y modo espejo, y busqueda de coincidencia en el diccionario.
  - Funcion classifyColor(): Muestreo RGB central y transformacion a espacio HSV para clasificar los 4 colores reglamentarios (Cian, Amarillo, Naranja, Magenta).
  - Funcion detectWhiteLine(): Calculo de centroide y desvio angular de lineas blancas sobre suelo verde.
  - Protocolo binario serie a 2,000,000 baudios y activacion del LED fisico en pin 2 durante 3.5 segundos continuos.

* aruco_dict.h y aruco_dict.cpp:
  - Matriz con las 4 rotaciones binarias (0, 90, 180 y 270 grados) de los 50 marcadores del diccionario oficial DICT_4X4_50.

* aruco_detector.h y aruco_lut.h:
  - Implementacion alternativa de alta velocidad basada en busqueda por componentes conexos en anchura (BFS) y tabla de consulta (LUT).

---

## 2. Scripts de Vision en Python (scripts_python/)

Para pruebas con camaras web locales o streams por red (celulares / camaras IP):

* detector_aruco.py:
  - Pipeline completo de deteccion en OpenCV (ArUco 4x4, colores del reglamento y linea blanca).
  - Enlace con camara IP (puerto 8081) o webcam USB local con reconexion automatica.
  - Interfaz grafica interactiva con botones en pantalla y transmision de comandos al ESP32 por puerto serie.

* leer_aruco_webcam.py:
  - Captura video de la webcam de la laptop, comprime cada fotograma a escala de grises de 80x60 en nibbles de 4 bits y los transmite por cable serie al ESP32 para validar que el microcontrolador procese la imagen.

* probar_vision_esp32.py:
  - Generador sintetico de marcadores ArUco para evaluar la precision del decodificador embebido del ESP32.

* servidor_web_serial.py:
  - Servidor HTTP local con pasarela de proxy (proxy_shot y proxy_stream) para enlazar el stream de video de un celular hacia las interfaces web sin problemas de CORS.

---

## 3. Interfaces de Usuario y Visores Web (interfaces_web/)

* aruco_grid.html:
  - Panel interactivo con soporte para WebSerial (cable a 2 Mbps) o Wi-Fi.
  - Superposicion (HUD) en vivo de esquinas detectadas, tiempo de procesamiento y diseñador interactivo de marcadores 4x4.

* camara_esp32.html:
  - Vista comparativa lado a lado entre la imagen capturada por la laptop/celular y la decodificacion calculada por el ESP32.
  - Reticula central para escaneo y clasificacion de color con retroalimentacion inmediata.

* camara_cable.html:
  - Visor especializado para recepcion de video directo por cable serie a 2 Mbps y conexion directa USB Host (pines 19 D- y 20 D+).
